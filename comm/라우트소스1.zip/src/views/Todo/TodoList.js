import React, {Component} from 'react'


export default class TodoList extends Component {
    
    constructor(){
        super()
    }

    render() {
        return(
            <div>
                <h1>Todo List</h1>
            </div>
        )
    }    
}