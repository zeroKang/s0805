import React, {Component} from 'react'
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import axios from 'axios'

export default class TodoList extends Component {
    
    constructor(props){
        super(props)
        console.log("constructor....")

    }

    getData = (page) => {
        
        
    }


    render() {
        //console.log(this.props)
        const page = this.props.match.params.page
  

        return(
            <div>
                <h1>Todo List {page}</h1>
                <ul>

                </ul>
                <Link to="/todoList/2">&nbsp;2&nbsp;</Link>
                <Link to="/todoList/3">&nbsp;3&nbsp;</Link>
                <Link to="/todoList/4">&nbsp;4&nbsp;</Link>
                <Link to="/todoList/5">&nbsp;5&nbsp;</Link>
            </div>
        )
    }    
}