import React from 'react'

export default function() {

    return(
        <div className='box'>
            <h1>MyPage </h1>
        </div>
    )
}