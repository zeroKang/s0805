import React from 'react'

export default function() {

    return(
        <div className='box'>
            <h1>Main Page</h1>
        </div>
    )
}